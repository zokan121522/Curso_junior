# De una lista de usuarios, ver solo nombres.

usuarios = [
    {"nombre" : "Jaime", "edad" : 41},
    {"nombre" : "Jesica", "edad" : 39}
]

for usuario in usuarios:
    print("nombre: ", usuario["nombre"])



