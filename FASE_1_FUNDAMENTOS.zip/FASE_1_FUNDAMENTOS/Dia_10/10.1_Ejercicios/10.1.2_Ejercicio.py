# Crear una lista
frutas = []

# Agregar frutas como diccionario

frutas.append({"nombre": "manzana","precio": 1.2})
frutas.append({"nombre": "pera","precio": 1.3})

# Recorro lista de frutas

for fruta in frutas:
    print("Fruta: ",fruta["nombre"], " - Precio", fruta["precio"])


