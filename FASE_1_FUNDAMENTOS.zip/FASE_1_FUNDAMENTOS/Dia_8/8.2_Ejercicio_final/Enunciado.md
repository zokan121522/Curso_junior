📋 Enunciado

Crea una página que tenga:
	1.	Un título centrado y en azul oscuro.
	2.	Un subtítulo con otra fuente.
	3.	Un párrafo informativo con fondo gris claro.
	4.	Una caja (div) con borde rojo y texto dentro.
	5.	Márgenes y rellenos aplicados de forma general a todos los elementos.