"""
Qué pide:
• Nombre
• Producto favorito
✔ Lógica:
Saluda y muestra selección.
"""

nombre = input("Nombre: ")
favorito = input("Producto favorito: ")

print(f"Hola {nombre}, tu producto favorito es {favorito}")