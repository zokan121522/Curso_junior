# hello.py
"""
Creamos un archivo básico que usa:
- Variables (str, int, float, bool)
- print() para mostrar en pantalla

"""
nombre = "zokan"    # string
edad = 41           # int
altura = 1.74       # float
estudiante = True   # bool

print ("Hola",nombre)
print ("Edad",edad)
print("altura",altura)
print("eres estudiante?",estudiante)



