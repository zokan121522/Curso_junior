# ejercicios_finales.py

"""
🧪 EJERCICIO 1 – Edad en el futuro**
Pide al usuario su edad y dile cuántos años tendrá dentro de 10 años.
"""

"""
edad = input(f"cuantos años tienes ")
edad_en_10_años= int(edad)+ 10
print (f"dentro de 10 años tendras: {edad_en_10_años}")
"""

#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#
#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#

"""
🧪 EJERCICIO 2 – Precio con IVA
Pide al usuario el precio de un producto sin IVA (21%) y muestra el precio final con IVA incluido.
"""

"""
precio_producto= input(f"Cuanto cuesta este producto? ")
precio_con_IVA= (int(precio_producto)* 21/100)+int(precio_producto) 
print(f"El precio del producto con iva es de {precio_con_IVA}")
"""

#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#
#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#

"""
🧪 EJERCICIO 3 – Área de un triángulo
Pide al usuario la base y la altura de un triángulo y calcula su área.
"""
"""
base = input (f"cual es la base del triangulo? ")
altura = input (f"cual es la altura del triangulo? ")
area= int(base)*int(altura)/2
print (f"El area del triangulo es de {area}")
"""

#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#
#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#

"""
🧪 EJERCICIO 4 – Conversión de minutos a segundos
Pide una cantidad de minutos y convierte a segundos.
"""

"""
minutos_pedidos= input(f"Cuantos minutos quieres? ")
segundos= int(minutos_pedidos) * 60
print(f"´ Los {minutos_pedidos} minutos que has solicitado son {segundos} segundos") 
"""

#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#
#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#__#


"""
🧪 EJERCICIO 5 – Saludo personalizado
Pide el nombre y el país del usuario y muestra un saludo tipo:
"""

"""
nombre= input(f"Hola como te llamas ? ")
pais = input(f"De donde eres")
print (f"Hola {nombre} eres de {pais} ? ")
"""